# Export Apigee (OPDK/Edge) Proxies Or SharedFlows

Use this tool to export the deployed revision of proxies or shared flows in Apigee OPDK or Apigee Edge. 
This tool can process one org, one env at a time only.

## Input Files
1. {WorkingDirectory}/config.json:
    {
        "username" : "<apgusernamehere>",
        "password" : "<apgpasswordhere>",
        "organization" : "<apgorghere>",
        "environment" : "<apgenvhere>",
        "mgmtServer" : "<apgmgmtserverhere>"
    }

## Output Files
1. reports
    - {WorkingDirectory}/reports/proxies/<org>/<env>: Summary of Deployed Proxies 
    - {WorkingDirectory}/reports/sharedflows/<org>/<env>: Summary of Deployed SharedFlows
2. export
    - {WorkingDirectory}/export/proxies/<org>/<env>: Exported Proxies 
    - {WorkingDirectory}/export/sharedflows/<org>/<env>: Exported SharedFlows

## Tool Dependencies
1. jq
    - To check: jq --version
    - To install in Mac: brew install jq
    - To install in Linux/Bash: sudo apt-get install jq
    - To install in Windows: sudo apt install -y jq

## Using the tool
1. Update the config.json file accordingly:
2. Install the tool dependencies.
3. Run this command in terminal to export all deployed proxies in env: ./exportProxies.sh
4. Run this command in terminal to export all deployed sharedflows in env: ./exportSharedFlows.sh
