#!/bin/bash

OIFS="$IFS"
IFS=$'\n'
                                            
rootPath=$(pwd)
org=$(jq -r '.organization' $rootPath/config.json)
env=$(jq -r '.environment' $rootPath/config.json)
usr=$(jq -r '.username' $rootPath/config.json)
psw=$(jq -r '.password' $rootPath/config.json)
msUrl=$(jq -r '.mgmtServer' $rootPath/config.json)
auth=`echo -n "$usr:$psw" | base64`

PARAMETERS=()
while [[ $# -gt 0 ]]
do
    param="$1"
    case $param in
        *)
        PARAMETERS+=("$1")
        shift
        ;;
    esac
done

exportSharedFlowsReportFile()
{
    path=reports/sharedflows/*/*/exportSharedFlowsReport.csv
    header=ORGANIZATION,ENVIRONMENT,NAME,REVISION
    csvReport $header $path
}

csvReport()
{   
    # csvReport - path
    folder=$(echo ${2} | cut -d '/' -f 1)
    typefolder=$(echo ${2} | cut -d '/' -f 2)
    orgfolder=$(echo ${2} | cut -d '/' -f 3)
    envfolder=$(echo ${2} | cut -d '/' -f 4)
    file=$(echo ${2} | cut -d '/' -f 5)

    # assign Var
    orgfolder=$(echo $org)
    envfolder=$(echo $env)

    # if not exists create reports folder
    if [ ! -d ${rootPath}/${folder}/${typefolder}/${orgfolder}/${envfolder} ]
    then
        mkdir -p "${rootPath}/${folder}/${typefolder}/${orgfolder}/${envfolder}" > /dev/null 2>&1 && echo "Directory $folder/$typefolder/$orgfolder/$envfolder created."
    fi

    # if not exists create exports folder
    if [ ! -d ${rootPath}/export/${typefolder}/${orgfolder}/${envfolder} ]
    then
        mkdir -p "${rootPath}/export/${typefolder}/${orgfolder}/${envfolder}" > /dev/null 2>&1 && echo "Directory export/$typefolder/$orgfolder/$envfolder created."
    fi

    # Create csv file
    if [ ! -f ${rootPath}/${folder}/${typefolder}/${orgfolder}/${envfolder}/${file} ] 
    then    
        touch ${rootPath}/${folder}/${typefolder}/${orgfolder}/${envfolder}/${file}
    fi

    # Write header on csv file
    if [ -f ${rootPath}/${folder}/${typefolder}/${orgfolder}/${envfolder}/${file} ] 
    then    
        echo $1 > ${rootPath}/${folder}/${typefolder}/${orgfolder}/${envfolder}/${file}
    fi

    exportFolder=${rootPath}/export/${typefolder}/${orgfolder}/${envfolder}
    reportFile=${rootPath}/reports/${typefolder}/${orgfolder}/${envfolder}/exportSharedFlowsReport.csv

    cd $rootPath
}

csv() 
{
    local items=("$@")
    for i in "${!items[@]}"
    do
        if [[ "${items[$i]}" =~ [,\"] ]]
        then
            items[$i]=\"$(echo -n "${items[$i]}" | sed s/\"/\"\"/g)\"
        fi
    done
    (
    IFS=,
    echo "${items[*]}"
    )
}

# Start of script
cd $rootPath

echo 'start time:' `date`

if [ -d ${rootPath}/reports/sharedflows/$org/$env ]
then
    rm -rf ${rootPath}/reports/sharedflows/$org/$env
    rm -rf ${rootPath}/export/sharedflows/$org/$env
fi

exportSharedFlowsReportFile

prevSharedflow=""
countDeployed=0
countExported=0

echo '******* Get List of SharedFlows in an Org *******'
orgSharedFlows=$(curl -H "Authorization: Basic $auth" -s -X GET "$msUrl/v1/organizations/$org/sharedflows")
statusCode=$(curl -H "Authorization: Basic $auth" -sS -I $msUrl/v1/organizations/$org/sharedflows 2> /dev/null | head -n 1 | cut -d' ' -f2)
echo "HTTP Status:" $statusCode

if [[ $statusCode != 200 ]] ; then
    echo "Unable to proceed. Please revisit the config file."
    exit
else
    echo '******* Get the Deployed Shared Flow Revision in an Env *******'
    for sharedflow in $(echo $orgSharedFlows | jq -r '.[]'); do
        sharedflowDeployments=$(curl -H "Authorization: Basic $auth" -s -X GET "$msUrl/v1/organizations/$org/sharedflows/$sharedflow/deployments")
        for sharedflowDeploymentsEnv in $(echo $sharedflowDeployments | jq -r '.environment | .[]' | jq '(.name + "," + .revision[].name)'); do
            depEnv=$(echo $sharedflowDeploymentsEnv | tr -d '"' | cut -d ',' -f1)
            depRev=$(echo $sharedflowDeploymentsEnv | tr -d '"' | cut -d ',' -f2)
            if [[ $env == $depEnv ]] ; then
                if grep -q ",$sharedflow," "$reportFile"
                then
                    if [[ $sharedflow == $prevSharedflow ]] ; then
                        echo "Multiple Revisions:" $sharedflow
                        # sed -i '' -e '$ d' "$reportFile" # For Mac
                        sed -i '$d' "$reportFile" # For Windows
                        csv $org $env $sharedflow $depRev >> $reportFile
                    fi
                else
                    csv $org $env $sharedflow $depRev >> $reportFile
                fi
                prevSharedflow=$sharedflow
                countDeployed=$((countDeployed+1))
            fi
        done
    done
    echo "Total SharedFlows Deployed:" $countDeployed

    echo '******* Export the Deployed Shared Flow Revision in an Env *******'
    while IFS="," read -r Org Env Name Rev
    do
        exportProxyRev=$(curl -H "Authorization: Basic $auth" -s -L -X GET "$msUrl/v1/organizations/$Org/sharedflows/$Name/revisions/$Rev?action=export&format=bundle" -o "$exportFolder/$Name.zip")
        statusCodeExport=$(curl -H "Authorization: Basic $auth" -sS -I $msUrl/v1/organizations/$Org/sharedflows/$Name/revisions/$Rev 2> /dev/null | head -n 1 | cut -d' ' -f2)
        if [[ $statusCodeExport != 200 ]] ; then
            echo "HTTP Status:" $statusCode
            echo "Download Status is FAILED for $Name--R$Rev"
        else
            # echo "Download Status is successful for $Name--R$Rev"
            countExported=$((countExported+1))
        fi
    done < <(tail -n +2 $reportFile | tr -d '\r')
    echo "Total SharedFlows Exported:" $countExported
fi

echo 'end time:' `date`
IFS="$OIFS"
